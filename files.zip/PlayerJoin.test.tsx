import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';
import { PlayerJoin } from '../pages/player/PlayerJoin';

// Mock supabase
vi.mock('../lib/supabase', () => ({
  supabase: {
    from: vi.fn(() => ({
      select: vi.fn().mockReturnThis(),
      insert: vi.fn().mockReturnThis(),
      eq: vi.fn().mockReturnThis(),
      single: vi.fn().mockResolvedValue({
        data: { id: 'room-123', status: 'lobby', game_mode: 'individual' },
        error: null,
      }),
    })),
  },
}));

// Mock framer-motion for faster tests
vi.mock('framer-motion', () => ({
  motion: {
    div: ({ children, ...props }: any) => <div {...props}>{children}</div>,
    form: ({ children, ...props }: any) => <form {...props}>{children}</form>,
    button: ({ children, ...props }: any) => <button {...props}>{children}</button>,
    header: ({ children, ...props }: any) => <header {...props}>{children}</header>,
    span: ({ children, ...props }: any) => <span {...props}>{children}</span>,
  },
  AnimatePresence: ({ children }: any) => children,
}));

// Mock KineticSpark (missing component)
vi.mock('../components/KineticSpark', () => ({
  KineticSpark: () => <div data-testid="kinetic-spark" />,
}));

// Skip 4-second intro in tests
vi.useFakeTimers();

const renderPlayerJoin = () => {
  return render(
    <MemoryRouter>
      <PlayerJoin />
    </MemoryRouter>
  );
};

describe('PlayerJoin', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
  });

  describe('Intro Animation Skip', () => {
    it('hides form during intro (first 4 seconds)', () => {
      renderPlayerJoin();
      // Intro is shown, form not yet visible
      expect(screen.queryByPlaceholderText(/ÖRN: 4X9B/i)).not.toBeInTheDocument();
    });

    it('shows form after intro completes', async () => {
      renderPlayerJoin();
      vi.advanceTimersByTime(4001);
      await waitFor(() => {
        expect(screen.getByPlaceholderText(/ÖRN: 4X9B/i)).toBeInTheDocument();
      });
    });
  });

  describe('Room Code Input', () => {
    beforeEach(() => vi.advanceTimersByTime(4001));

    it('auto-uppercases room code', async () => {
      renderPlayerJoin();
      await waitFor(() => screen.getByPlaceholderText(/ÖRN: 4X9B/i));

      const input = screen.getByPlaceholderText(/ÖRN: 4X9B/i);
      await userEvent.type(input, 'abc1');
      expect(input).toHaveValue('ABC1');
    });

    it('limits room code to 4 characters (maxLength)', async () => {
      renderPlayerJoin();
      await waitFor(() => screen.getByPlaceholderText(/ÖRN: 4X9B/i));

      const input = screen.getByPlaceholderText(/ÖRN: 4X9B/i);
      expect(input).toHaveAttribute('maxLength', '4');
    });

    it('pre-fills room code from URL query param', () => {
      render(
        <MemoryRouter initialEntries={['/join?code=XY9Z']}>
          <PlayerJoin />
        </MemoryRouter>
      );
      vi.advanceTimersByTime(4001);
      // URL code should be pre-filled in state
      // This tests the urlCode initialization
    });
  });

  describe('Submit Button State', () => {
    beforeEach(() => vi.advanceTimersByTime(4001));

    it('submit button has correct text when nickname is empty', async () => {
      renderPlayerJoin();
      await waitFor(() => screen.getByText(/SAVAŞA KATIL/i));

      const btn = screen.getByText(/SAVAŞA KATIL/i).closest('button');
      expect(btn).not.toHaveClass('bg-alaz-orange'); // not highlighted without nickname
    });

    it('submit button highlights when nickname is filled', async () => {
      renderPlayerJoin();
      await waitFor(() => screen.getByPlaceholderText(/Efsane Oyuncu/i));

      await userEvent.type(screen.getByPlaceholderText(/Efsane Oyuncu/i), 'TestPlayer');
      const btn = screen.getByText(/SAVAŞA KATIL/i).closest('button');
      expect(btn).toHaveClass('bg-alaz-orange');
    });
  });

  describe('Team Mode', () => {
    it('shows team name input when game_mode is team', async () => {
      const { supabase } = await import('../lib/supabase');
      vi.mocked(supabase.from).mockReturnValue({
        select: vi.fn().mockReturnThis(),
        eq: vi.fn().mockReturnThis(),
        single: vi.fn().mockResolvedValue({
          data: { game_mode: 'team' },
          error: null,
        }),
      } as any);

      renderPlayerJoin();
      vi.advanceTimersByTime(4001);

      // Simulate entering a 4-char code which triggers the team mode check
      const codeInput = await screen.findByPlaceholderText(/ÖRN: 4X9B/i);
      await userEvent.type(codeInput, 'TEST');

      await waitFor(() => {
        expect(screen.getByPlaceholderText(/Masa 5/i)).toBeInTheDocument();
      });
    });
  });

  describe('Join Flow — Happy Path', () => {
    it('stores session in localStorage after successful join', async () => {
      const { supabase } = await import('../lib/supabase');
      const mockInsert = vi.fn().mockReturnThis();
      vi.mocked(supabase.from).mockReturnValue({
        select: vi.fn().mockReturnThis(),
        insert: mockInsert,
        eq: vi.fn().mockReturnThis(),
        single: vi.fn()
          .mockResolvedValueOnce({ data: { id: 'room-1', status: 'lobby', game_mode: 'individual' }, error: null })
          .mockResolvedValueOnce({ data: { id: 'player-1', nickname: 'TestPlayer', team_name: null }, error: null }),
      } as any);

      renderPlayerJoin();
      vi.advanceTimersByTime(4001);

      await userEvent.type(await screen.findByPlaceholderText(/ÖRN: 4X9B/i), 'TEST');
      await userEvent.type(screen.getByPlaceholderText(/Efsane Oyuncu/i), 'TestPlayer');
      fireEvent.submit(screen.getByText(/SAVAŞA KATIL/i).closest('form')!);

      await waitFor(() => {
        expect(localStorage.getItem('cafe_game_playerId')).toBe('player-1');
        expect(localStorage.getItem('cafe_game_roomId')).toBe('room-1');
        expect(localStorage.getItem('cafe_game_playerName')).toBe('TestPlayer');
      });
    });
  });

  describe('Error Handling', () => {
    it('shows error when room not found', async () => {
      const { supabase } = await import('../lib/supabase');
      vi.mocked(supabase.from).mockReturnValue({
        select: vi.fn().mockReturnThis(),
        eq: vi.fn().mockReturnThis(),
        single: vi.fn().mockResolvedValue({ data: null, error: { message: 'Not found' } }),
      } as any);

      renderPlayerJoin();
      vi.advanceTimersByTime(4001);

      await userEvent.type(await screen.findByPlaceholderText(/ÖRN: 4X9B/i), 'XXXX');
      await userEvent.type(screen.getByPlaceholderText(/Efsane Oyuncu/i), 'TestPlayer');
      fireEvent.submit(screen.getByText(/SAVAŞA KATIL/i).closest('form')!);

      await waitFor(() => {
        expect(screen.getByText(/TV ekranındaki kodu kontrol edin/i)).toBeInTheDocument();
      });
    });

    it('shows error when game already started', async () => {
      const { supabase } = await import('../lib/supabase');
      vi.mocked(supabase.from).mockReturnValue({
        select: vi.fn().mockReturnThis(),
        eq: vi.fn().mockReturnThis(),
        single: vi.fn().mockResolvedValue({
          data: { id: 'room-1', status: 'playing', game_mode: 'individual' },
          error: null
        }),
      } as any);

      renderPlayerJoin();
      vi.advanceTimersByTime(4001);

      await userEvent.type(await screen.findByPlaceholderText(/ÖRN: 4X9B/i), 'BUSY');
      await userEvent.type(screen.getByPlaceholderText(/Efsane Oyuncu/i), 'TestPlayer');
      fireEvent.submit(screen.getByText(/SAVAŞA KATIL/i).closest('form')!);

      await waitFor(() => {
        expect(screen.getByText(/Oyun çoktan başlamış/i)).toBeInTheDocument();
      });
    });
  });
});
