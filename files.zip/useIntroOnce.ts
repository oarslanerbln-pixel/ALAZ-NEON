/**
 * useIntroOnce — Custom Hook
 * 
 * PROBLEM GELÖST:
 * Jede Seite (LandingPage, HostSetup, PlayerJoin, PlayerGame, HostDisplay)
 * hat denselben showIntro-State + 4-Sekunden-Timer.
 * 
 * Navigiert ein User: Landing → Join → /play
 * erlebt er 3 × 4 Sekunden = 12 Sekunden warten NUR für Intro-Animationen.
 * 
 * FIX: sessionStorage-Flag — Intro wird pro Browser-Session nur einmal gezeigt.
 * 
 * VERWENDUNG:
 *   const showIntro = useIntroOnce();
 *   // Statt:
 *   const [showIntro, setShowIntro] = useState(true);
 *   useEffect(() => { const t = setTimeout(() => setShowIntro(false), 4000); return () => clearTimeout(t); }, []);
 */
import { useState, useEffect } from 'react';

const INTRO_KEY = 'alaz_intro_shown';
const INTRO_DURATION_MS = 4000;

export function useIntroOnce(): boolean {
  const alreadySeen = typeof window !== 'undefined'
    ? sessionStorage.getItem(INTRO_KEY) === 'true'
    : true;

  const [showIntro, setShowIntro] = useState(!alreadySeen);

  useEffect(() => {
    if (alreadySeen) return;

    const timer = setTimeout(() => {
      setShowIntro(false);
      sessionStorage.setItem(INTRO_KEY, 'true');
    }, INTRO_DURATION_MS);

    return () => clearTimeout(timer);
  }, [alreadySeen]);

  return showIntro;
}
