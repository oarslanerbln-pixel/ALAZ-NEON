import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useIntroOnce } from './useIntroOnce';

vi.useFakeTimers();

describe('useIntroOnce', () => {
  beforeEach(() => {
    sessionStorage.clear();
  });

  it('shows intro on first visit', () => {
    const { result } = renderHook(() => useIntroOnce());
    expect(result.current).toBe(true);
  });

  it('hides intro after 4 seconds', () => {
    const { result } = renderHook(() => useIntroOnce());
    expect(result.current).toBe(true);

    act(() => { vi.advanceTimersByTime(4001); });
    expect(result.current).toBe(false);
  });

  it('skips intro on subsequent calls (same session)', () => {
    sessionStorage.setItem('alaz_intro_shown', 'true');
    const { result } = renderHook(() => useIntroOnce());
    expect(result.current).toBe(false);
  });

  it('saves flag to sessionStorage after intro completes', () => {
    renderHook(() => useIntroOnce());
    expect(sessionStorage.getItem('alaz_intro_shown')).toBeNull();

    act(() => { vi.advanceTimersByTime(4001); });
    expect(sessionStorage.getItem('alaz_intro_shown')).toBe('true');
  });
});
