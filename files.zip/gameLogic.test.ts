/**
 * SCORING LOGIC UNIT TESTS
 * Tests the core scoring algorithm extracted from HostDisplay.tsx endRound()
 * 
 * Scoring rules:
 * - Unique answer:  +20 pts
 * - Shared answer:  +10 pts
 * - Wrong letter:   +0 pts
 * - Early submit bonus (first player to click "early submit"): +15 pts
 */
import { describe, it, expect } from 'vitest';

// ── Extracted & isolated scoring logic from HostDisplay.tsx ──
interface AnswerRecord {
  player_id: string;
  data: Record<string, string>;
  created_at: string;
}

interface ScoredResult {
  playerId: string;
  roundScore: number;
  answers: Record<string, { value: string; isUnique: boolean; points: number; isValid: boolean }>;
  earlyBonus: boolean;
}

function scoreRound(
  answers: AnswerRecord[],
  categories: string[],
  activeLetter: string
): ScoredResult[] {
  const normalizedLetter = activeLetter.toLowerCase();

  // Count occurrences per category per normalized value
  const categoryCounts: Record<string, Record<string, number>> = {};
  categories.forEach(cat => categoryCounts[cat] = {});

  answers.forEach(answer => {
    categories.forEach(cat => {
      const val = (answer.data[cat] || '').trim().toLowerCase();
      if (val && val.startsWith(normalizedLetter)) {
        categoryCounts[cat][val] = (categoryCounts[cat][val] || 0) + 1;
      }
    });
  });

  // Find earliest player who submitted early
  let earliestPlayerId: string | null = null;
  for (const answer of answers) {
    if (answer.data['_earlySubmit'] === 'true') {
      earliestPlayerId = answer.player_id;
      break;
    }
  }

  return answers.map(answer => {
    let roundScore = 0;
    const breakdown: ScoredResult['answers'] = {};

    categories.forEach(cat => {
      const valRaw = answer.data[cat] || '';
      const val = valRaw.trim().toLowerCase();
      let isUnique = false, pts = 0, isValid = false;

      if (val && val.startsWith(normalizedLetter)) {
        isValid = true;
        if (categoryCounts[cat][val] === 1) { isUnique = true; pts = 20; }
        else { pts = 10; }
      }
      roundScore += pts;
      breakdown[cat] = { value: valRaw, isUnique, points: pts, isValid };
    });

    const gotEarlyBonus = answer.player_id === earliestPlayerId;
    if (gotEarlyBonus) roundScore += 15;

    return { playerId: answer.player_id, roundScore, answers: breakdown, earlyBonus: gotEarlyBonus };
  });
}

// ── TESTS ──
describe('Scoring Logic', () => {
  const categories = ['Şehir', 'Hayvan', 'İsim'];

  describe('Unique vs Shared Answers', () => {
    it('awards 20 points for a unique answer', () => {
      const answers: AnswerRecord[] = [
        { player_id: 'p1', data: { Şehir: 'Ankara', Hayvan: 'Aslan', İsim: 'Ali', _earlySubmit: 'false' }, created_at: '1' },
        { player_id: 'p2', data: { Şehir: 'Adana', Hayvan: 'Aslan', İsim: 'Ayşe', _earlySubmit: 'false' }, created_at: '2' },
      ];

      const results = scoreRound(answers, categories, 'A');

      const p1 = results.find(r => r.playerId === 'p1')!;
      expect(p1.answers['Şehir'].isUnique).toBe(true);
      expect(p1.answers['Şehir'].points).toBe(20);
    });

    it('awards 10 points for a shared answer', () => {
      const answers: AnswerRecord[] = [
        { player_id: 'p1', data: { Şehir: 'Ankara', Hayvan: '', İsim: '', _earlySubmit: 'false' }, created_at: '1' },
        { player_id: 'p2', data: { Şehir: 'Ankara', Hayvan: '', İsim: '', _earlySubmit: 'false' }, created_at: '2' },
      ];

      const results = scoreRound(answers, categories, 'A');
      results.forEach(r => {
        expect(r.answers['Şehir'].isUnique).toBe(false);
        expect(r.answers['Şehir'].points).toBe(10);
      });
    });

    it('awards 0 points for wrong starting letter', () => {
      const answers: AnswerRecord[] = [
        { player_id: 'p1', data: { Şehir: 'İstanbul', Hayvan: '', İsim: '', _earlySubmit: 'false' }, created_at: '1' },
      ];

      const results = scoreRound(answers, categories, 'A');
      expect(results[0].answers['Şehir'].isValid).toBe(false);
      expect(results[0].answers['Şehir'].points).toBe(0);
    });

    it('awards 0 points for empty answers', () => {
      const answers: AnswerRecord[] = [
        { player_id: 'p1', data: { Şehir: '', Hayvan: '', İsim: '', _earlySubmit: 'false' }, created_at: '1' },
      ];

      const results = scoreRound(answers, categories, 'A');
      expect(results[0].roundScore).toBe(0);
    });
  });

  describe('Early Submit Bonus', () => {
    it('awards +15 to first player with _earlySubmit: true', () => {
      const answers: AnswerRecord[] = [
        { player_id: 'p1', data: { Şehir: 'Ankara', Hayvan: '', İsim: '', _earlySubmit: 'true' }, created_at: '1' },
        { player_id: 'p2', data: { Şehir: 'Adana', Hayvan: '', İsim: '', _earlySubmit: 'true' }, created_at: '2' },
      ];

      const results = scoreRound(answers, categories, 'A');

      const p1 = results.find(r => r.playerId === 'p1')!;
      const p2 = results.find(r => r.playerId === 'p2')!;

      expect(p1.earlyBonus).toBe(true);
      expect(p1.roundScore).toBe(20 + 15); // unique + early
      expect(p2.earlyBonus).toBe(false);
      expect(p2.roundScore).toBe(20); // unique, no early bonus
    });

    it('does not award early bonus if nobody submitted early', () => {
      const answers: AnswerRecord[] = [
        { player_id: 'p1', data: { Şehir: 'Ankara', Hayvan: '', İsim: '', _earlySubmit: 'false' }, created_at: '1' },
      ];

      const results = scoreRound(answers, categories, 'A');
      expect(results[0].earlyBonus).toBe(false);
      expect(results[0].roundScore).toBe(20); // unique only
    });
  });

  describe('Edge Cases', () => {
    it('handles case-insensitive deduplication (ankara == ANKARA)', () => {
      const answers: AnswerRecord[] = [
        { player_id: 'p1', data: { Şehir: 'Ankara', Hayvan: '', İsim: '', _earlySubmit: 'false' }, created_at: '1' },
        { player_id: 'p2', data: { Şehir: 'ANKARA', Hayvan: '', İsim: '', _earlySubmit: 'false' }, created_at: '2' },
      ];

      const results = scoreRound(answers, categories, 'A');
      // Both should get 10 (shared), not 20 (unique)
      results.forEach(r => expect(r.answers['Şehir'].points).toBe(10));
    });

    it('handles no players', () => {
      const results = scoreRound([], categories, 'A');
      expect(results).toHaveLength(0);
    });

    it('handles single player — always unique', () => {
      const answers: AnswerRecord[] = [
        { player_id: 'p1', data: { Şehir: 'Ankara', Hayvan: 'Aslan', İsim: 'Ali', _earlySubmit: 'false' }, created_at: '1' },
      ];

      const results = scoreRound(answers, categories, 'A');
      expect(results[0].answers['Şehir'].isUnique).toBe(true);
      expect(results[0].answers['Hayvan'].isUnique).toBe(true);
      expect(results[0].answers['İsim'].isUnique).toBe(true);
      expect(results[0].roundScore).toBe(60); // 3 × 20
    });

    it('⚠️ BUG: Turkish letter I/İ case collision', () => {
      // 'istanbul'.startsWith('i') = true, but active letter is displayed as 'İ'
      // This is a known limitation noted in HostDisplay source code
      const answers: AnswerRecord[] = [
        { player_id: 'p1', data: { Şehir: 'istanbul', Hayvan: '', İsim: '', _earlySubmit: 'false' }, created_at: '1' },
      ];

      // With letter 'İ', normalized to 'i̇' (lowercase dotted i)
      const results = scoreRound(answers, categories, 'İ');
      // 'istanbul'.toLowerCase() = 'istanbul', 'İ'.toLowerCase() = 'i̇' 
      // 'istanbul'.startsWith('i̇') = FALSE — Turkish İ edge case
      // This is the documented bug in the source
      expect(results[0].answers['Şehir'].isValid).toBe(false); // Bug confirmed
    });
  });
});
